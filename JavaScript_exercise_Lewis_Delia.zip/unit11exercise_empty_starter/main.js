// 3
console.log("Hello World!");

// 4a
console.log("Hello, My name is Delia Lewis");

// 4b
console.log("This is a 'single quoted statement' and this is a \"double quouted statement\"");

// 5a
console.log("2 plus 2 equals " + (2+2));

// 5b
console.log("56 divided by 7 equals " + (56/7));

// 5c
console.log("42.6 times 18.3 equals " + (42.6 * 18.3));

// 5d
console.log("83.97 minus 34.86 equals " + (83.97-34.86));

// 5e
console.log ("49 mod 8 equals " + (49%8));

// 6a
console.log("The answer is: " + (5+4+3/2*6-1));

// 6b
console.log("The answer is: " + (29*75+32/8));

// 6c
console.log("The answer is: " + ((42+89)*3)/(72-36));

// 6d
console.log("The answer is: " + (4%3));

// 6e


// 7a
console.log("The type of '23' is: " + typeof(56));

// 7b
console.log("The type of '43.211' is: " + typeof(43.211));

// 7c
console.log("The type of '2' is: " + typeof("2"));

// 7d
console.log("The type of 'two' is: " + typeof("two"));

// 7e
console.log("The type of 'new Date' is: " + typeof(new Date()));

// 7f
console.log("The type of '[]' is: " + typeof([]));

// 7g
console.log("The type of '{}' is: " + typeof({}));

// 7h
console.log("The type of 'true' is: " + typeof(true));

// 7i
console.log("The type of 'True' is: " + typeof(True));

// 7j
console.log("The type of 'false' is: " + typeof(false));

// 7k
console.log("The type of 'False' is: " + typeof(False));

// 7l
console.log("The type of 'false' is: " + typeof("false"));

// 7m
console.log("The type of 'Null' is: " + typeof(Null));

// 7n
console.log("The type of 'Undefined' is: " + typeof(Undefined));

// 7o
console.log("The type of 'NaN' is: " + typeof(NaN));

// 7p
console.log("The type of '0' is: " + typeof(0));

// 7q
console.log("The type of '0' is: " + typeof("0"));

// 7r


// 8a
var foo = 2;
var bar = 3;

// 8b
var total = 5;

// 8c
total = 11;

// 8d
total = 3.66;

// 8e
total= 13.39;

// 8f
console.log("The final total is: 13.39, when starting values are 'foo': 2 and 'bar': 3");